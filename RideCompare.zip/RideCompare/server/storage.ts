import { 
  type User, type InsertUser, 
  type GoodDeed, type InsertGoodDeed,
  type UserGoodDeed, type InsertUserGoodDeed,
  type Donation, type InsertDonation,
  type HelpRequest, type InsertHelpRequest,
  type HallOfFameEntry, type InsertHallOfFameEntry,
  type UserDashboard, type CommunityStats,
  users, goodDeeds, userGoodDeeds, donations, helpRequests, hallOfFame
} from "@shared/schema";
import { db } from "./db";
import { eq, desc, count, sum, sql } from "drizzle-orm";

export interface IStorage {
  // User methods
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  createUser(insertUser: InsertUser): Promise<User>;
  updateUserKarma(userId: string, karmaChange: number): Promise<void>;
  
  // Good deeds methods
  getGoodDeeds(limit?: number): Promise<GoodDeed[]>;
  getGoodDeedsByCategory(category: string): Promise<GoodDeed[]>;
  getPersonalizedGoodDeeds(userId: string): Promise<GoodDeed[]>;
  completeGoodDeed(userId: string, goodDeedId: string, proof?: string): Promise<UserGoodDeed>;
  getUserGoodDeeds(userId: string): Promise<UserGoodDeed[]>;
  
  // Donation methods
  createDonation(donation: InsertDonation): Promise<Donation>;
  getDonations(limit?: number): Promise<Donation[]>;
  getUserDonations(userId: string): Promise<Donation[]>;
  updateDonationStatus(donationId: string, status: string, trackingInfo?: any): Promise<void>;
  
  // Help request methods
  createHelpRequest(helpRequest: InsertHelpRequest): Promise<HelpRequest>;
  getHelpRequests(status?: string): Promise<HelpRequest[]>;
  getUserHelpRequests(userId: string): Promise<HelpRequest[]>;
  updateHelpRequest(requestId: string, updates: Partial<HelpRequest>): Promise<void>;
  
  // Hall of Fame methods
  getHallOfFame(category?: string, period?: string): Promise<HallOfFameEntry[]>;
  updateHallOfFame(): Promise<void>;
  
  // Dashboard methods
  getUserDashboard(userId: string): Promise<UserDashboard>;
  getCommunityStats(): Promise<CommunityStats>;
}

export class DatabaseStorage implements IStorage {
  
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user || undefined;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user || undefined;
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.email, email));
    return user || undefined;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(insertUser)
      .returning();
    return user;
  }

  async updateUserKarma(userId: string, karmaChange: number): Promise<void> {
    await db
      .update(users)
      .set({ 
        karmaPoints: sql`${users.karmaPoints} + ${karmaChange}`,
        updatedAt: new Date()
      })
      .where(eq(users.id, userId));
  }

  async getGoodDeeds(limit: number = 20): Promise<GoodDeed[]> {
    return await db
      .select()
      .from(goodDeeds)
      .where(eq(goodDeeds.isActive, true))
      .orderBy(desc(goodDeeds.createdAt))
      .limit(limit);
  }

  async getGoodDeedsByCategory(category: string): Promise<GoodDeed[]> {
    return await db
      .select()
      .from(goodDeeds)
      .where(eq(goodDeeds.category, category))
      .orderBy(desc(goodDeeds.karmaReward));
  }

  async getPersonalizedGoodDeeds(userId: string): Promise<GoodDeed[]> {
    // For now, return easy and medium difficulty good deeds
    // In the future, this could be based on user level, location, preferences
    return await db
      .select()
      .from(goodDeeds)
      .where(eq(goodDeeds.isActive, true))
      .orderBy(desc(goodDeeds.karmaReward))
      .limit(10);
  }

  async completeGoodDeed(userId: string, goodDeedId: string, proof?: string): Promise<UserGoodDeed> {
    // Get the good deed to calculate karma
    const [goodDeed] = await db.select().from(goodDeeds).where(eq(goodDeeds.id, goodDeedId));
    if (!goodDeed) {
      throw new Error("Good deed not found");
    }

    // Create the completion record
    const [completion] = await db
      .insert(userGoodDeeds)
      .values({
        userId,
        goodDeedId,
        proof,
        karmaAwarded: goodDeed.karmaReward,
        isVerified: false // Could be auto-verified for some deeds
      })
      .returning();

    // Update user's karma
    await this.updateUserKarma(userId, goodDeed.karmaReward);

    return completion;
  }

  async getUserGoodDeeds(userId: string): Promise<UserGoodDeed[]> {
    return await db
      .select()
      .from(userGoodDeeds)
      .where(eq(userGoodDeeds.userId, userId))
      .orderBy(desc(userGoodDeeds.completedAt));
  }

  async createDonation(donation: InsertDonation): Promise<Donation> {
    const [newDonation] = await db
      .insert(donations)
      .values(donation)
      .returning();
    
    // Award karma for donation
    const karmaAmount = donation.type === 'financial' 
      ? Math.floor((donation.amount as any) || 0) 
      : 10; // Fixed karma for item donations
    
    if (karmaAmount > 0) {
      await this.updateUserKarma(donation.donorId, karmaAmount);
    }

    return newDonation;
  }

  async getDonations(limit: number = 20): Promise<Donation[]> {
    return await db
      .select()
      .from(donations)
      .orderBy(desc(donations.donatedAt))
      .limit(limit);
  }

  async getUserDonations(userId: string): Promise<Donation[]> {
    return await db
      .select()
      .from(donations)
      .where(eq(donations.donorId, userId))
      .orderBy(desc(donations.donatedAt));
  }

  async updateDonationStatus(donationId: string, status: string, trackingInfo?: any): Promise<void> {
    await db
      .update(donations)
      .set({ 
        status,
        trackingInfo,
        ...(status === 'delivered' && { deliveredAt: new Date() })
      })
      .where(eq(donations.id, donationId));
  }

  async createHelpRequest(helpRequest: InsertHelpRequest): Promise<HelpRequest> {
    const [newRequest] = await db
      .insert(helpRequests)
      .values(helpRequest)
      .returning();
    return newRequest;
  }

  async getHelpRequests(status?: string): Promise<HelpRequest[]> {
    const query = db.select().from(helpRequests);
    
    if (status) {
      return await query
        .where(eq(helpRequests.status, status))
        .orderBy(desc(helpRequests.createdAt));
    }
    
    return await query.orderBy(desc(helpRequests.createdAt));
  }

  async getUserHelpRequests(userId: string): Promise<HelpRequest[]> {
    return await db
      .select()
      .from(helpRequests)
      .where(eq(helpRequests.requesterId, userId))
      .orderBy(desc(helpRequests.createdAt));
  }

  async updateHelpRequest(requestId: string, updates: Partial<HelpRequest>): Promise<void> {
    await db
      .update(helpRequests)
      .set(updates)
      .where(eq(helpRequests.id, requestId));
  }

  async getHallOfFame(category?: string, period?: string): Promise<HallOfFameEntry[]> {
    const baseQuery = db.select().from(hallOfFame).where(eq(hallOfFame.isActive, true));
    
    if (category && period) {
      return await baseQuery
        .where(sql`${hallOfFame.isActive} = true AND ${hallOfFame.category} = ${category} AND ${hallOfFame.period} = ${period}`)
        .orderBy(desc(hallOfFame.value));
    } else if (category) {
      return await baseQuery
        .where(sql`${hallOfFame.isActive} = true AND ${hallOfFame.category} = ${category}`)
        .orderBy(desc(hallOfFame.value));
    } else if (period) {
      return await baseQuery
        .where(sql`${hallOfFame.isActive} = true AND ${hallOfFame.period} = ${period}`)
        .orderBy(desc(hallOfFame.value));
    }
    
    return await baseQuery.orderBy(desc(hallOfFame.value));
  }

  async updateHallOfFame(): Promise<void> {
    // This would typically be run as a scheduled job
    // For now, we'll create some sample entries
    
    // Top karma earners
    const topKarmaUsers = await db
      .select({
        userId: users.id,
        totalKarma: users.karmaPoints,
        username: users.username
      })
      .from(users)
      .orderBy(desc(users.karmaPoints))
      .limit(3);

    // Update hall of fame entries for top karma earners
    for (const user of topKarmaUsers) {
      await db
        .insert(hallOfFame)
        .values({
          userId: user.userId,
          achievement: "Top Karma Earner",
          description: `Earned ${user.totalKarma} karma points through good deeds`,
          category: "karma_champion",
          period: "monthly",
          value: user.totalKarma || 0
        })
        .onConflictDoNothing(); // Avoid duplicates
    }
  }

  async getUserDashboard(userId: string): Promise<UserDashboard> {
    const user = await this.getUser(userId);
    if (!user) {
      throw new Error("User not found");
    }

    const [recentGoodDeeds, userDonations, userRequests, hallEntries] = await Promise.all([
      this.getUserGoodDeeds(userId),
      this.getUserDonations(userId),
      this.getUserHelpRequests(userId),
      db.select().from(hallOfFame).where(eq(hallOfFame.userId, userId))
    ]);

    // Calculate stats
    const totalDonationsAmount = userDonations
      .filter(d => d.type === 'financial' && d.amount)
      .reduce((sum, d) => sum + parseFloat(d.amount || '0'), 0);

    const stats = {
      totalKarma: user.karmaPoints || 0,
      goodDeedsCompleted: recentGoodDeeds.length,
      donationsAmount: totalDonationsAmount,
      helpRequestsFulfilled: userRequests.filter(r => r.status === 'completed').length
    };

    return {
      user,
      recentGoodDeeds,
      donations: userDonations,
      helpRequests: userRequests,
      hallOfFameEntries: hallEntries,
      stats
    };
  }

  async getCommunityStats(): Promise<CommunityStats> {
    const [userCount, goodDeedCount, donationCount, helpRequestCount] = await Promise.all([
      db.select({ count: count() }).from(users),
      db.select({ count: count() }).from(userGoodDeeds),
      db.select({ count: count() }).from(donations),
      db.select({ count: count() }).from(helpRequests)
    ]);

    // Get recent activity (simplified)
    const recentActivity = [
      { type: "good_deed", user: "Community Member", action: "completed a good deed", timestamp: new Date() },
      { type: "donation", user: "Anonymous", action: "made a donation", timestamp: new Date() },
      { type: "help_request", user: "Community Member", action: "requested help", timestamp: new Date() }
    ];

    return {
      totalUsers: userCount[0]?.count || 0,
      totalGoodDeeds: goodDeedCount[0]?.count || 0,
      totalDonations: donationCount[0]?.count || 0,
      totalHelpRequests: helpRequestCount[0]?.count || 0,
      recentActivity
    };
  }

  // Seed data for development
  async seedMockData(): Promise<void> {
    try {
      // Create sample users
      const sampleUsers: InsertUser[] = [
        {
          username: "kindness_hero",
          email: "hero@goodnesshub.com",
          fullName: "Alex Johnson",
          bio: "Spreading kindness one deed at a time",
          karmaPoints: 850,
          level: 5,
          location: "San Francisco, CA",
          isVerified: true
        },
        {
          username: "community_helper",
          email: "helper@goodnesshub.com", 
          fullName: "Maria Garcia",
          bio: "Here to help my community",
          karmaPoints: 620,
          level: 4,
          location: "Austin, TX",
          isVerified: true
        },
        {
          username: "earth_guardian",
          email: "earth@goodnesshub.com",
          fullName: "David Chen",
          bio: "Environmental activist passionate about sustainability",
          karmaPoints: 740,
          level: 4,
          location: "Portland, OR",
          isVerified: true
        },
        {
          username: "helping_hands",
          email: "hands@goodnesshub.com",
          fullName: "Sarah Wilson",
          bio: "Always ready to lend a helping hand",
          karmaPoints: 430,
          level: 3,
          location: "Denver, CO"
        },
        {
          username: "mentor_mike",
          email: "mentor@goodnesshub.com",
          fullName: "Michael Brown",
          bio: "Dedicated to educating and mentoring youth",
          karmaPoints: 590,
          level: 3,
          location: "Boston, MA"
        }
      ];

      // Create sample good deeds
      const sampleGoodDeeds: InsertGoodDeed[] = [
        {
          title: "Pick up litter in local park",
          description: "Spend 30 minutes cleaning up trash in your neighborhood park",
          category: "environmental",
          difficulty: "easy",
          karmaReward: 15,
          timeRequired: "30 minutes",
          location: "Local parks"
        },
        {
          title: "Help elderly neighbor with groceries", 
          description: "Assist an elderly neighbor with carrying groceries or shopping",
          category: "community",
          difficulty: "easy",
          karmaReward: 20,
          timeRequired: "1 hour",
          location: "Neighborhood"
        },
        {
          title: "Volunteer at local food bank",
          description: "Help sort and distribute food at your local food bank",
          category: "helping",
          difficulty: "medium", 
          karmaReward: 50,
          timeRequired: "3 hours",
          location: "Food banks"
        },
        {
          title: "Mentor a student",
          description: "Provide tutoring or mentorship to a student in need",
          category: "education",
          difficulty: "hard",
          karmaReward: 100,
          timeRequired: "2 hours weekly",
          location: "Schools/Online"
        },
        {
          title: "Plant trees in community",
          description: "Join tree planting initiative to improve air quality and beautify the area",
          category: "environmental",
          difficulty: "medium",
          karmaReward: 35,
          timeRequired: "2 hours",
          location: "Community spaces"
        },
        {
          title: "Visit senior center",
          description: "Spend time with elderly residents, play games, or share stories",
          category: "community",
          difficulty: "easy",
          karmaReward: 25,
          timeRequired: "1.5 hours",
          location: "Senior centers"
        },
        {
          title: "Organize clothing drive",
          description: "Collect and distribute clothing to those in need",
          category: "helping",
          difficulty: "hard",
          karmaReward: 75,
          timeRequired: "1 week",
          location: "Community centers"
        },
        {
          title: "Teach digital literacy",
          description: "Help adults learn basic computer and internet skills",
          category: "education",
          difficulty: "medium",
          karmaReward: 45,
          timeRequired: "2 hours",
          location: "Libraries/Centers"
        }
      ];

      // Create sample help requests
      const sampleHelpRequests: InsertHelpRequest[] = [
        {
          requesterId: "placeholder", // Will be updated after users are created
          title: "Need help moving furniture",
          description: "Moving to a new apartment and need assistance with heavy furniture. Have a truck but need strong hands!",
          category: "community",
          urgency: "medium",
          location: "Downtown Seattle",
          isFinancial: false
        },
        {
          requesterId: "placeholder",
          title: "Fundraising for animal shelter",
          description: "Our local animal shelter needs funds for medical supplies and food for rescued animals.",
          category: "helping",
          urgency: "high",
          location: "Portland Animal Shelter",
          isFinancial: true,
          targetAmount: "5000.00",
          currentAmount: "1200.00"
        },
        {
          requesterId: "placeholder",
          title: "Tutoring needed for high school math",
          description: "Struggling with calculus and need someone to help with homework and exam preparation.",
          category: "education",
          urgency: "medium",
          location: "Online/Boston area",
          isFinancial: false
        },
        {
          requesterId: "placeholder",
          title: "Community garden cleanup",
          description: "Our neighborhood garden needs volunteers to help with weeding, planting, and maintenance.",
          category: "environmental",
          urgency: "low",
          location: "Riverside Community Garden",
          isFinancial: false
        },
        {
          requesterId: "placeholder",
          title: "Medical expense assistance",
          description: "Family member needs surgery and we're struggling with medical bills. Any help appreciated.",
          category: "helping",
          urgency: "critical",
          location: "San Francisco Bay Area",
          isFinancial: true,
          targetAmount: "12000.00",
          currentAmount: "3400.00"
        }
      ];

      // Insert sample data - first check if users already exist
      const existingUsers = await db.select().from(users).limit(1);
      let userIds: string[] = [];
      
      if (existingUsers.length === 0) {
        // Insert new users
        const insertedUsers = await db.insert(users).values(sampleUsers).returning();
        userIds = insertedUsers.map(u => u.id);
      } else {
        // Get existing user IDs
        const allUsers = await db.select().from(users).limit(5);
        userIds = allUsers.map(u => u.id);
      }
      
      await db.insert(goodDeeds).values(sampleGoodDeeds).onConflictDoNothing();
      
      // Update help requests with actual user IDs
      if (userIds.length > 0) {
        const helpRequestsWithUserIds = sampleHelpRequests.map((request, index) => ({
          ...request,
          requesterId: userIds[index % userIds.length]
        }));
        
        await db.insert(helpRequests).values(helpRequestsWithUserIds).onConflictDoNothing();
        
        // Create some sample donations
        const sampleDonations = [
          {
            donorId: userIds[0],
            type: "financial" as const,
            amount: "500.00",
            status: "completed" as const,
            karmaAwarded: 50
          },
          {
            donorId: userIds[1],
            type: "item" as const,
            itemDescription: "Winter clothing collection",
            status: "completed" as const,
            karmaAwarded: 25
          },
          {
            donorId: userIds[2] || userIds[0],
            type: "financial" as const,
            amount: "200.00",
            status: "pending" as const,
            karmaAwarded: 20
          }
        ];
        
        await db.insert(donations).values(sampleDonations).onConflictDoNothing();
        
        // Create hall of fame entries
        const sampleHallOfFame = [
          {
            userId: userIds[0],
            achievement: "Top Karma Earner",
            description: "Earned the most karma points this month through consistent good deeds",
            category: "karma_champion",
            period: "monthly",
            value: 850
          },
          {
            userId: userIds[2] || userIds[0],
            achievement: "Environmental Champion",
            description: "Led multiple environmental initiatives and tree planting events",
            category: "environmental_hero",
            period: "monthly",
            value: 740
          },
          {
            userId: userIds[1] || userIds[0],
            achievement: "Community Builder",
            description: "Helped organize community events and connected neighbors",
            category: "community_leader",
            period: "monthly",
            value: 620
          },
          {
            userId: userIds[4] || userIds[0],
            achievement: "Education Advocate",
            description: "Mentored over 20 students and improved literacy rates",
            category: "education_mentor",
            period: "monthly",
            value: 590
          },
          {
            userId: userIds[3] || userIds[0],
            achievement: "Rising Star",
            description: "New member making incredible impact in the community",
            category: "newcomer_champion",
            period: "monthly",
            value: 430
          }
        ];
        
        await db.insert(hallOfFame).values(sampleHallOfFame).onConflictDoNothing();
      }
      
      console.log("Sample data seeded successfully");
    } catch (error) {
      console.error("Error seeding data:", error);
    }
  }
}

export const storage = new DatabaseStorage();
