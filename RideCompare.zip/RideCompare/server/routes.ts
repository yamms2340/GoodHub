import type { Express } from "express";
import { createServer, type Server } from "http";
import { Server as SocketIOServer } from "socket.io";
import { storage } from "./storage";
import { 
  completeGoodDeedSchema, createDonationSchema, createHelpRequestSchema,
  insertUserSchema
} from "@shared/schema";
import { z } from "zod";

export function registerRoutes(app: Express): Server {
  const httpServer = createServer(app);

  // Initialize Socket.io with proper CORS settings
  const io = new SocketIOServer(httpServer, {
    cors: {
      origin: "*",
      methods: ["GET", "POST"]
    }
  });

  // Socket.io connection handling
  io.on('connection', (socket) => {
    console.log('User connected:', socket.id);

    socket.on('join_room', (room) => {
      socket.join(room);
    });

    socket.on('disconnect', () => {
      console.log('User disconnected:', socket.id);
    });
  });

  // Seed database on startup
  storage.seedMockData().catch(console.error);

  // User routes
  app.post("/api/users", async (req, res) => {
    try {
      const validatedData = insertUserSchema.parse(req.body);
      const user = await storage.createUser(validatedData);
      res.status(201).json(user);
    } catch (error) {
      console.error("Create user error:", error);
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: error.errors });
      }
      res.status(500).json({ error: "Internal server error" });
    }
  });

  app.get("/api/users/:id", async (req, res) => {
    try {
      const user = await storage.getUser(req.params.id);
      if (!user) {
        return res.status(404).json({ error: "User not found" });
      }
      res.json(user);
    } catch (error) {
      console.error("Get user error:", error);
      res.status(500).json({ error: "Internal server error" });
    }
  });

  app.get("/api/users/:id/dashboard", async (req, res) => {
    try {
      const dashboard = await storage.getUserDashboard(req.params.id);
      res.json(dashboard);
    } catch (error) {
      console.error("Get dashboard error:", error);
      res.status(500).json({ error: "Internal server error" });
    }
  });

  // Good deeds routes
  app.get("/api/good-deeds", async (req, res) => {
    try {
      const limit = req.query.limit ? parseInt(req.query.limit as string) : 20;
      const category = req.query.category as string;
      
      let goodDeeds;
      if (category) {
        goodDeeds = await storage.getGoodDeedsByCategory(category);
      } else {
        goodDeeds = await storage.getGoodDeeds(limit);
      }
      
      res.json(goodDeeds);
    } catch (error) {
      console.error("Get good deeds error:", error);
      res.status(500).json({ error: "Internal server error" });
    }
  });

  app.get("/api/good-deeds/personalized/:userId", async (req, res) => {
    try {
      const goodDeeds = await storage.getPersonalizedGoodDeeds(req.params.userId);
      res.json(goodDeeds);
    } catch (error) {
      console.error("Get personalized good deeds error:", error);
      res.status(500).json({ error: "Internal server error" });
    }
  });

  app.post("/api/good-deeds/complete", async (req, res) => {
    try {
      const validatedData = completeGoodDeedSchema.parse(req.body);
      const userId = req.headers['user-id'] as string; // In a real app, this would come from auth
      
      if (!userId) {
        return res.status(401).json({ error: "User authentication required" });
      }

      const completion = await storage.completeGoodDeed(
        userId,
        validatedData.goodDeedId,
        validatedData.proof
      );

      // Emit real-time update
      io.emit('good_deed_completed', {
        userId,
        goodDeedId: validatedData.goodDeedId,
        karmaAwarded: completion.karmaAwarded
      });

      res.status(201).json(completion);
    } catch (error) {
      console.error("Complete good deed error:", error);
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: error.errors });
      }
      res.status(500).json({ error: "Internal server error" });
    }
  });

  // Donation routes
  app.get("/api/donations", async (req, res) => {
    try {
      const limit = req.query.limit ? parseInt(req.query.limit as string) : 20;
      const donations = await storage.getDonations(limit);
      res.json(donations);
    } catch (error) {
      console.error("Get donations error:", error);
      res.status(500).json({ error: "Internal server error" });
    }
  });

  app.post("/api/donations", async (req, res) => {
    try {
      const validatedData = createDonationSchema.parse(req.body);
      const userId = req.headers['user-id'] as string;
      
      if (!userId) {
        return res.status(401).json({ error: "User authentication required" });
      }

      const donation = await storage.createDonation({
        ...validatedData,
        donorId: userId,
        amount: validatedData.amount ? validatedData.amount.toString() : undefined
      });

      // Emit real-time update for donation tracking
      io.emit('donation_created', {
        donationId: donation.id,
        type: donation.type,
        amount: donation.amount,
        status: donation.status
      });

      res.status(201).json(donation);
    } catch (error) {
      console.error("Create donation error:", error);
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: error.errors });
      }
      res.status(500).json({ error: "Internal server error" });
    }
  });

  app.patch("/api/donations/:id/status", async (req, res) => {
    try {
      const { status, trackingInfo } = req.body;
      await storage.updateDonationStatus(req.params.id, status, trackingInfo);

      // Emit real-time tracking update
      io.emit('donation_status_updated', {
        donationId: req.params.id,
        status,
        trackingInfo
      });

      res.json({ success: true });
    } catch (error) {
      console.error("Update donation status error:", error);
      res.status(500).json({ error: "Internal server error" });
    }
  });

  // Help request routes
  app.get("/api/help-requests", async (req, res) => {
    try {
      const status = req.query.status as string;
      const helpRequests = await storage.getHelpRequests(status);
      res.json(helpRequests);
    } catch (error) {
      console.error("Get help requests error:", error);
      res.status(500).json({ error: "Internal server error" });
    }
  });

  app.post("/api/help-requests", async (req, res) => {
    try {
      const validatedData = createHelpRequestSchema.parse(req.body);
      const userId = req.headers['user-id'] as string;
      
      if (!userId) {
        return res.status(401).json({ error: "User authentication required" });
      }

      const helpRequest = await storage.createHelpRequest({
        ...validatedData,
        requesterId: userId,
        targetAmount: validatedData.targetAmount ? validatedData.targetAmount.toString() : undefined
      });

      // Emit real-time update for new help request
      io.emit('help_request_created', helpRequest);

      res.status(201).json(helpRequest);
    } catch (error) {
      console.error("Create help request error:", error);
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: error.errors });
      }
      res.status(500).json({ error: "Internal server error" });
    }
  });

  app.patch("/api/help-requests/:id", async (req, res) => {
    try {
      await storage.updateHelpRequest(req.params.id, req.body);
      
      // Emit real-time update
      io.emit('help_request_updated', {
        requestId: req.params.id,
        updates: req.body
      });

      res.json({ success: true });
    } catch (error) {
      console.error("Update help request error:", error);
      res.status(500).json({ error: "Internal server error" });
    }
  });

  // Hall of Fame routes
  app.get("/api/hall-of-fame", async (req, res) => {
    try {
      const category = req.query.category as string;
      const period = req.query.period as string;
      const hallOfFame = await storage.getHallOfFame(category, period);
      res.json(hallOfFame);
    } catch (error) {
      console.error("Get hall of fame error:", error);
      res.status(500).json({ error: "Internal server error" });
    }
  });

  // Community stats route
  app.get("/api/community/stats", async (req, res) => {
    try {
      const stats = await storage.getCommunityStats();
      res.json(stats);
    } catch (error) {
      console.error("Get community stats error:", error);
      res.status(500).json({ error: "Internal server error" });
    }
  });

  return httpServer;
}