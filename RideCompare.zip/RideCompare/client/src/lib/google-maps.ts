export interface GoogleMapsConfig {
  apiKey: string;
  libraries: string[];
}

export const loadGoogleMapsScript = (config: GoogleMapsConfig): Promise<void> => {
  return new Promise((resolve, reject) => {
    // Check if Google Maps is already loaded
    if (window.google && window.google.maps) {
      resolve();
      return;
    }

    // Check if script is already loading
    const existingScript = document.querySelector('script[src*="maps.googleapis.com"]');
    if (existingScript) {
      existingScript.addEventListener('load', () => resolve());
      existingScript.addEventListener('error', reject);
      return;
    }

    const script = document.createElement('script');
    script.type = 'text/javascript';
    script.src = `https://maps.googleapis.com/maps/api/js?key=${config.apiKey}&libraries=${config.libraries.join(',')}`;
    script.async = true;
    script.defer = true;
    
    script.onload = () => resolve();
    script.onerror = () => reject(new Error('Failed to load Google Maps script'));
    
    document.head.appendChild(script);
  });
};

export const geocodeAddress = async (address: string): Promise<any[]> => {
  return new Promise((resolve, reject) => {
    const google = (window as any).google;
    if (!google?.maps) {
      reject(new Error("Google Maps not loaded"));
      return;
    }
    
    const geocoder = new google.maps.Geocoder();
    
    geocoder.geocode({ address }, (results: any, status: any) => {
      if (status === google.maps.GeocoderStatus.OK && results) {
        resolve(results);
      } else {
        reject(new Error(`Geocoding failed: ${status}`));
      }
    });
  });
};

export const calculateRoute = async (
  origin: string | any,
  destination: string | any
): Promise<any> => {
  return new Promise((resolve, reject) => {
    const google = (window as any).google;
    if (!google?.maps) {
      reject(new Error("Google Maps not loaded"));
      return;
    }
    
    const directionsService = new google.maps.DirectionsService();
    
    directionsService.route(
      {
        origin,
        destination,
        travelMode: google.maps.TravelMode.DRIVING,
        unitSystem: google.maps.UnitSystem.IMPERIAL,
        avoidHighways: false,
        avoidTolls: false,
      },
      (result: any, status: any) => {
        if (status === google.maps.DirectionsStatus.OK && result) {
          resolve(result);
        } else {
          reject(new Error(`Directions request failed: ${status}`));
        }
      }
    );
  });
};
