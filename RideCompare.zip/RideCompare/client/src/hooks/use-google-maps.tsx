import { useState, useEffect } from "react";
import { loadGoogleMapsScript, type GoogleMapsConfig } from "@/lib/google-maps";

export function useGoogleMaps() {
  const [isLoaded, setIsLoaded] = useState(false);
  const [loadError, setLoadError] = useState<Error | null>(null);

  useEffect(() => {
    const apiKey = import.meta.env.VITE_GOOGLE_MAPS_API_KEY;

    if (!apiKey) {
      setLoadError(new Error("Google Maps API key is not configured"));
      return;
    }

    const config: GoogleMapsConfig = {
      apiKey,
      libraries: ["places", "geometry"],
    };

    loadGoogleMapsScript(config)
      .then(() => {
        setIsLoaded(true);
        setLoadError(null);
      })
      .catch((error) => {
        setLoadError(error);
        setIsLoaded(false);
      });
  }, []);

  return { isLoaded, loadError };
}
