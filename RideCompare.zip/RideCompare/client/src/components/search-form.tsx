import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { Search, MapPin, ArrowUpDown, Clock, User } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Form, FormControl, FormField, FormItem, FormLabel } from "@/components/ui/form";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { searchRequestSchema, type SearchRequest, type RideComparisonResponse } from "@shared/schema";

interface SearchFormProps {
  onSearchResults: (results: RideComparisonResponse) => void;
  onSearchStart: () => void;
  onSearchEnd: () => void;
}

export default function SearchForm({ onSearchResults, onSearchStart, onSearchEnd }: SearchFormProps) {
  const [passengers, setPassengers] = useState(1);
  const { toast } = useToast();

  const form = useForm<SearchRequest>({
    resolver: zodResolver(searchRequestSchema),
    defaultValues: {
      pickup: "",
      destination: "",
      passengers: 1,
    },
  });

  const handleSwapLocations = () => {
    const pickup = form.getValues("pickup");
    const destination = form.getValues("destination");
    form.setValue("pickup", destination);
    form.setValue("destination", pickup);
  };

  const onSubmit = async (data: SearchRequest) => {
    try {
      onSearchStart();
      
      const response = await apiRequest("POST", "/api/rides/search", data);
      const results: RideComparisonResponse = await response.json();
      
      onSearchResults(results);
      
      toast({
        title: "Rides found!",
        description: `Found ${results.rides.length} available rides for your route.`,
      });
    } catch (error) {
      toast({
        title: "Search failed",
        description: "Unable to find rides. Please check your locations and try again.",
        variant: "destructive",
      });
    } finally {
      onSearchEnd();
    }
  };

  return (
    <div className="bg-white rounded-2xl shadow-xl p-6 lg:p-8 max-w-4xl mx-auto">
      <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)}>
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-4 items-end">
            <div className="lg:col-span-4">
              <FormField
                control={form.control}
                name="pickup"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel className="block text-sm font-medium text-gray-700 mb-2">
                      <div className="flex items-center">
                        <div className="w-2 h-2 bg-secondary rounded-full mr-2"></div>
                        Pickup Location
                      </div>
                    </FormLabel>
                    <FormControl>
                      <div className="relative">
                        <Input 
                          {...field}
                          placeholder="Enter pickup address" 
                          className="pr-10"
                        />
                        <MapPin className="absolute right-3 top-3 h-4 w-4 text-gray-400" />
                      </div>
                    </FormControl>
                  </FormItem>
                )}
              />
            </div>
            
            <div className="lg:col-span-1 flex justify-center">
              <Button 
                type="button"
                variant="ghost"
                size="sm"
                onClick={handleSwapLocations}
                className="p-2 text-gray-400 hover:text-primary transition-colors duration-300"
              >
                <ArrowUpDown className="h-4 w-4" />
              </Button>
            </div>
            
            <div className="lg:col-span-4">
              <FormField
                control={form.control}
                name="destination"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel className="block text-sm font-medium text-gray-700 mb-2">
                      <div className="flex items-center">
                        <MapPin className="w-3 h-3 text-red-500 mr-2" />
                        Destination
                      </div>
                    </FormLabel>
                    <FormControl>
                      <div className="relative">
                        <Input 
                          {...field}
                          placeholder="Enter destination address" 
                          className="pr-10"
                        />
                        <Search className="absolute right-3 top-3 h-4 w-4 text-gray-400" />
                      </div>
                    </FormControl>
                  </FormItem>
                )}
              />
            </div>
            
            <div className="lg:col-span-3">
              <Button 
                type="submit" 
                className="w-full btn-primary py-3"
                disabled={form.formState.isSubmitting}
              >
                {form.formState.isSubmitting ? (
                  <>
                    <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                    Searching...
                  </>
                ) : (
                  <>
                    <Search className="h-4 w-4 mr-2" />
                    Compare Rides
                  </>
                )}
              </Button>
            </div>
          </div>
          
          <div className="flex flex-wrap gap-4 mt-4 text-sm text-gray-600">
            <div className="flex items-center">
              <Clock className="h-4 w-4 mr-2 text-accent" />
              <span>Leave now</span>
              <button type="button" className="ml-2 text-primary hover:underline">
                Change
              </button>
            </div>
            <div className="flex items-center">
              <User className="h-4 w-4 mr-2" />
              <span>{passengers} passenger{passengers !== 1 ? 's' : ''}</span>
              <button type="button" className="ml-2 text-primary hover:underline">
                Change
              </button>
            </div>
          </div>
        </form>
      </Form>
    </div>
  );
}
