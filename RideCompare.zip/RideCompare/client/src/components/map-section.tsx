import { useEffect, useRef } from "react";
import { Map, Plus, Minus, Navigation, Clock } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useGoogleMaps } from "@/hooks/use-google-maps";
import type { RideComparisonResponse } from "@shared/schema";

interface MapSectionProps {
  searchResults: RideComparisonResponse | null;
  className?: string;
}

export default function MapSection({ searchResults, className }: MapSectionProps) {
  const mapRef = useRef<HTMLDivElement>(null);
  const { isLoaded, loadError } = useGoogleMaps();

  useEffect(() => {
    if (isLoaded && mapRef.current && !loadError && (window as any).google?.maps) {
      const map = new (window as any).google.maps.Map(mapRef.current, {
        zoom: 13,
        center: { lat: 37.7749, lng: -122.4194 }, // Default to San Francisco
        styles: [
          {
            featureType: "poi",
            elementType: "labels.text.fill",
            stylers: [{ color: "#757575" }],
          },
          {
            featureType: "poi.park",
            elementType: "labels.text.fill",
            stylers: [{ color: "#9e9e9e" }],
          },
        ],
      });

      // If we have search results, show route
      if (searchResults) {
        // This would typically use the Google Directions service
        // For now, we'll just center the map
        map.setZoom(12);
      }
    }
  }, [isLoaded, loadError, searchResults]);

  if (loadError) {
    return (
      <div className={className}>
        <div className="bg-white rounded-2xl shadow-lg overflow-hidden">
          <div className="p-4 border-b border-gray-200">
            <h3 className="text-lg font-semibold text-dark flex items-center">
              <Map className="h-5 w-5 mr-2 text-primary" />
              Route Preview
            </h3>
          </div>
          
          <div className="relative h-96 lg:h-[500px] bg-red-50 flex items-center justify-center">
            <div className="text-center p-8">
              <Map className="h-16 w-16 text-red-300 mx-auto mb-4" />
              <p className="text-red-600 font-medium">Failed to load map</p>
              <p className="text-sm text-red-500 mt-2">
                Please check your internet connection or try again later
              </p>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className={className}>
      <div className="bg-white rounded-2xl shadow-lg overflow-hidden">
        <div className="p-4 border-b border-gray-200">
          <h3 className="text-lg font-semibold text-dark flex items-center">
            <Map className="h-5 w-5 mr-2 text-primary" />
            Route Preview
          </h3>
        </div>
        
        <div className="relative h-96 lg:h-[500px]">
          {!isLoaded ? (
            <div className="absolute inset-0 bg-gradient-to-br from-blue-100 to-green-100 flex items-center justify-center">
              <div className="text-center p-8">
                <div className="animate-pulse">
                  <Map className="h-16 w-16 text-primary/50 mx-auto mb-4" />
                  <p className="text-gray-600 font-medium">Loading map...</p>
                </div>
              </div>
            </div>
          ) : (
            <div ref={mapRef} className="w-full h-full" />
          )}
          
          {/* Map Controls */}
          <div className="absolute top-4 right-4 flex flex-col gap-2">
            <Button size="sm" variant="outline" className="bg-white p-2 shadow-md">
              <Plus className="h-4 w-4" />
            </Button>
            <Button size="sm" variant="outline" className="bg-white p-2 shadow-md">
              <Minus className="h-4 w-4" />
            </Button>
            <Button size="sm" variant="outline" className="bg-white p-2 shadow-md">
              <Navigation className="h-4 w-4" />
            </Button>
          </div>
          
          {/* Route Info Overlay */}
          {searchResults && (
            <div className="absolute bottom-4 left-4 right-4">
              <div className="bg-white/95 backdrop-blur-sm rounded-xl p-4 shadow-lg">
                <div className="flex items-center justify-between text-sm">
                  <div className="flex items-center text-gray-600">
                    <Navigation className="h-4 w-4 mr-2" />
                    <span>{searchResults.routeInfo.distance}</span>
                  </div>
                  <div className="flex items-center text-gray-600">
                    <Clock className="h-4 w-4 mr-2" />
                    <span>{searchResults.routeInfo.duration}</span>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
