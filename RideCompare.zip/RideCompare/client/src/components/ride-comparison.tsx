import { useState } from "react";
import { Star, Crown, RefreshCw } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/utils";
import type { RideComparisonResponse, Ride } from "@shared/schema";

interface RideComparisonProps {
  searchResults: RideComparisonResponse | null;
  isLoading: boolean;
  className?: string;
}

export default function RideComparison({ searchResults, isLoading, className }: RideComparisonProps) {
  const [selectedRide, setSelectedRide] = useState<string | null>(null);

  const getServiceIcon = (provider: string, serviceType: string) => {
    const key = `${provider.toLowerCase()}-${serviceType.toLowerCase().replace(/\s+/g, '-')}`;
    
    const serviceClasses = {
      'uber-uberx': 'service-uber',
      'lyft-lyft': 'service-lyft',
      'metro cab-standard': 'service-metro',
      'uber-uber black': 'service-premium',
    };

    const serviceLetters = {
      'uber-uberx': 'U',
      'lyft-lyft': 'L',
      'metro cab-standard': 'M',
      'uber-uber black': <Crown className="h-4 w-4 text-accent" />,
    };

    return {
      className: serviceClasses[key as keyof typeof serviceClasses] || 'bg-gray-500',
      content: serviceLetters[key as keyof typeof serviceLetters] || provider[0].toUpperCase(),
    };
  };

  const getBestPriceBadge = (ride: Ride, rides: Ride[]) => {
    const prices = rides.map(r => parseFloat(r.price));
    const minPrice = Math.min(...prices);
    const maxEta = Math.max(...rides.map(r => r.eta));
    
    if (parseFloat(ride.price) === minPrice) {
      return <Badge className="bg-secondary/10 text-secondary">Best Price</Badge>;
    }
    
    if (ride.eta === Math.min(...rides.map(r => r.eta))) {
      return <Badge className="bg-primary/10 text-primary">Fastest Pickup</Badge>;
    }
    
    return null;
  };

  if (isLoading) {
    return (
      <div className={className}>
        <div className="sticky top-4">
          <div className="bg-white rounded-2xl shadow-lg p-6">
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-lg font-semibold text-dark">Searching rides...</h3>
              <div className="flex items-center text-sm text-gray-500">
                <RefreshCw className="h-4 w-4 mr-2 animate-spin" />
                <span>Loading</span>
              </div>
            </div>
            
            <div className="space-y-4">
              {[1, 2, 3, 4].map((i) => (
                <div key={i} className="border border-gray-200 rounded-xl p-4 animate-pulse">
                  <div className="flex items-center justify-between mb-3">
                    <div className="flex items-center">
                      <div className="w-10 h-10 bg-gray-200 rounded-lg mr-3"></div>
                      <div>
                        <div className="w-20 h-4 bg-gray-200 rounded mb-1"></div>
                        <div className="w-16 h-3 bg-gray-200 rounded"></div>
                      </div>
                    </div>
                    <div className="text-right">
                      <div className="w-16 h-5 bg-gray-200 rounded mb-1"></div>
                      <div className="w-20 h-3 bg-gray-200 rounded"></div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    );
  }

  if (!searchResults) {
    return (
      <div className={className}>
        <div className="sticky top-4">
          <div className="bg-white rounded-2xl shadow-lg p-6">
            <h3 className="text-lg font-semibold text-dark mb-6">Available Rides</h3>
            <div className="text-center py-8">
              <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <RefreshCw className="h-8 w-8 text-gray-400" />
              </div>
              <p className="text-gray-500">Enter pickup and destination to see available rides</p>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className={className}>
      <div className="sticky top-4">
        <div className="bg-white rounded-2xl shadow-lg p-6">
          <div className="flex items-center justify-between mb-6">
            <h3 className="text-lg font-semibold text-dark">Available Rides</h3>
            <div className="flex items-center text-sm text-gray-500">
              <RefreshCw className="h-4 w-4 mr-2" />
              <span>Updated just now</span>
            </div>
          </div>
          
          <div className="space-y-4">
            {searchResults.rides.map((ride) => {
              const serviceIcon = getServiceIcon(ride.serviceProvider, ride.serviceType);
              const isSelected = selectedRide === ride.id;
              
              return (
                <div
                  key={ride.id}
                  className={cn(
                    "ride-card rounded-xl p-4 cursor-pointer",
                    isSelected && "selected"
                  )}
                  onClick={() => setSelectedRide(ride.id)}
                >
                  <div className="flex items-center justify-between mb-3">
                    <div className="flex items-center">
                      <div className={cn(
                        "w-10 h-10 rounded-lg flex items-center justify-center mr-3 text-white font-bold text-sm",
                        serviceIcon.className
                      )}>
                        {serviceIcon.content}
                      </div>
                      <div>
                        <h4 className="font-semibold text-dark">{ride.serviceType}</h4>
                        <p className="text-sm text-gray-500">
                          {ride.isPremium ? 'Premium • ' : ''}{ride.seats} seats
                        </p>
                      </div>
                    </div>
                    <div className="text-right">
                      <p className="text-lg font-bold text-dark">${ride.price}</p>
                      <p className="text-sm text-gray-500">{ride.eta} min away</p>
                    </div>
                  </div>
                  
                  <div className="flex items-center justify-between text-xs text-gray-500">
                    <span className="flex items-center">
                      <Star className="h-3 w-3 text-accent mr-1 fill-current" />
                      <span>{ride.rating}</span>
                    </span>
                    <span>{ride.duration}</span>
                  </div>
                  
                  {getBestPriceBadge(ride, searchResults.rides) && (
                    <div className="mt-2">
                      {getBestPriceBadge(ride, searchResults.rides)}
                    </div>
                  )}
                </div>
              );
            })}
          </div>
          
          {/* Price Comparison Summary */}
          <div className="mt-6 p-4 bg-light rounded-xl">
            <h4 className="font-medium text-dark mb-2">Price Range</h4>
            <div className="flex items-center justify-between text-sm">
              <span className="text-secondary font-semibold">
                Lowest: ${searchResults.priceRange.lowest.toFixed(2)}
              </span>
              <span className="text-gray-500">
                Avg: ${searchResults.priceRange.average.toFixed(2)}
              </span>
              <span className="text-red-500 font-semibold">
                Highest: ${searchResults.priceRange.highest.toFixed(2)}
              </span>
            </div>
            <div className="w-full bg-gray-200 rounded-full h-2 mt-2">
              <div 
                className="bg-gradient-to-r from-secondary to-red-500 h-2 rounded-full" 
                style={{ width: "100%" }}
              />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
