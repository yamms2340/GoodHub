import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { X, MapPin } from "lucide-react";
import { Button } from "@/components/ui/button";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import type { Search } from "@shared/schema";

export default function RecentSearches() {
  const queryClient = useQueryClient();
  const { toast } = useToast();

  const { data: searches, isLoading } = useQuery<Search[]>({
    queryKey: ["/api/searches/recent"],
  });

  const deleteSearchMutation = useMutation({
    mutationFn: async (id: string) => {
      const response = await apiRequest("DELETE", `/api/searches/${id}`);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/searches/recent"] });
      toast({
        title: "Search removed",
        description: "Recent search has been deleted successfully.",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to remove search. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleRemoveSearch = (e: React.MouseEvent, id: string) => {
    e.stopPropagation();
    deleteSearchMutation.mutate(id);
  };

  const formatDate = (date: Date | string) => {
    const searchDate = new Date(date);
    const now = new Date();
    const diffTime = Math.abs(now.getTime() - searchDate.getTime());
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    
    if (diffDays === 1) return "Today";
    if (diffDays === 2) return "Yesterday";
    if (diffDays <= 7) return `${diffDays - 1} days ago`;
    return searchDate.toLocaleDateString();
  };

  if (isLoading) {
    return (
      <section className="mt-12">
        <h2 className="text-2xl font-bold text-dark mb-6">Recent Searches</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {[1, 2, 3].map((i) => (
            <div key={i} className="bg-white rounded-xl p-4 shadow-sm border border-gray-200 animate-pulse">
              <div className="flex items-center justify-between mb-2">
                <div className="w-20 h-4 bg-gray-200 rounded"></div>
                <div className="w-4 h-4 bg-gray-200 rounded"></div>
              </div>
              <div className="space-y-2">
                <div className="w-32 h-4 bg-gray-200 rounded"></div>
                <div className="w-40 h-4 bg-gray-200 rounded"></div>
              </div>
              <div className="flex items-center justify-between mt-3 pt-3 border-t border-gray-100">
                <div className="w-16 h-3 bg-gray-200 rounded"></div>
                <div className="w-12 h-4 bg-gray-200 rounded"></div>
              </div>
            </div>
          ))}
        </div>
      </section>
    );
  }

  if (!searches || searches.length === 0) {
    return (
      <section className="mt-12">
        <h2 className="text-2xl font-bold text-dark mb-6">Recent Searches</h2>
        <div className="text-center py-8">
          <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
            <MapPin className="h-8 w-8 text-gray-400" />
          </div>
          <p className="text-gray-500">No recent searches yet</p>
          <p className="text-sm text-gray-400 mt-1">Your search history will appear here</p>
        </div>
      </section>
    );
  }

  return (
    <section className="mt-12">
      <h2 className="text-2xl font-bold text-dark mb-6">Recent Searches</h2>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {searches.map((search) => (
          <div
            key={search.id}
            className="bg-white rounded-xl p-4 shadow-sm border border-gray-200 hover:shadow-md transition-shadow duration-300 cursor-pointer"
          >
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm text-gray-500">
                {formatDate(search.searchDate!)}
              </span>
              <Button
                variant="ghost"
                size="sm"
                className="text-gray-400 hover:text-red-500 h-auto p-1"
                onClick={(e) => handleRemoveSearch(e, search.id)}
                disabled={deleteSearchMutation.isPending}
              >
                <X className="h-4 w-4" />
              </Button>
            </div>
            
            <div className="space-y-2">
              <div className="flex items-center text-sm">
                <div className="w-2 h-2 bg-secondary rounded-full mr-2"></div>
                <span className="text-gray-700 truncate">{search.pickupLocation}</span>
              </div>
              <div className="flex items-center text-sm">
                <MapPin className="w-3 h-3 text-red-500 mr-2" />
                <span className="text-gray-700 truncate">{search.destinationLocation}</span>
              </div>
            </div>
            
            <div className="flex items-center justify-between mt-3 pt-3 border-t border-gray-100">
              <span className="text-xs text-gray-500">Best price was</span>
              <span className="text-sm font-semibold text-secondary">
                ${search.bestPrice}
              </span>
            </div>
          </div>
        ))}
      </div>
    </section>
  );
}
