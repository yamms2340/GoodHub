import { TrendingUp, Clock, Shield } from "lucide-react";

export default function FeaturesSection() {
  const features = [
    {
      icon: TrendingUp,
      title: "Compare Prices",
      description: "See real-time prices from multiple ride services and choose the best deal for your budget.",
      bgColor: "bg-primary/10",
      iconColor: "text-primary",
    },
    {
      icon: Clock,
      title: "Save Time",
      description: "No need to switch between apps. Get all your ride options in one convenient location.",
      bgColor: "bg-secondary/10",
      iconColor: "text-secondary",
    },
    {
      icon: Shield,
      title: "Trusted Platform",
      description: "Secure booking through official partner apps with transparent pricing and reliable service.",
      bgColor: "bg-accent/10",
      iconColor: "text-accent",
    },
  ];

  return (
    <section className="mt-16 py-12">
      <div className="text-center mb-12">
        <h2 className="text-3xl font-bold text-dark mb-4">Why Choose EasyCabs?</h2>
        <p className="text-xl text-gray-600 max-w-2xl mx-auto">
          Save time and money by comparing all your ride options in one place
        </p>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        {features.map((feature, index) => (
          <div key={index} className="text-center">
            <div className={`w-16 h-16 ${feature.bgColor} rounded-2xl flex items-center justify-center mx-auto mb-4`}>
              <feature.icon className={`h-8 w-8 ${feature.iconColor}`} />
            </div>
            <h3 className="text-xl font-semibold text-dark mb-2">{feature.title}</h3>
            <p className="text-gray-600">{feature.description}</p>
          </div>
        ))}
      </div>
    </section>
  );
}
