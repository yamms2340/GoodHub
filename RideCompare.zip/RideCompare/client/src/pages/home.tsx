import { useState, useEffect, useCallback } from "react";
import { Heart, Users, Sparkles, Gift, HelpCircle, Trophy, Star, MapPin, Clock, CheckCircle, AlertCircle, Zap, TrendingUp } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { useSocket, useSocketEvent } from "@/hooks/use-socket";
import { useToast } from "@/hooks/use-toast";
import { motion, AnimatePresence } from "framer-motion";

// Sample user ID for demo - in real app this would come from auth
// Use a valid user ID from the database
const DEMO_USER_ID = "b4d03360-2ebc-43ab-a095-5430ceb0760f";

interface GoodDeed {
  id: string;
  title: string;
  description: string;
  category: string;
  difficulty: string;
  karmaReward: number;
  timeRequired: string;
}

interface HelpRequest {
  id: string;
  title: string;
  description: string;
  category: string;
  urgency: string;
  location?: string;
  isFinancial: boolean;
  targetAmount?: string;
  currentAmount?: string;
  requesterId: string;
  status: string;
}

interface HallOfFameEntry {
  id: string;
  achievement: string;
  description: string;
  category: string;
  period: string;
  value: number;
  userId: string;
}

interface User {
  id: string;
  username: string;
  fullName: string;
  avatar?: string;
  karmaPoints: number;
  level: number;
  isVerified: boolean;
}

interface Donation {
  id: string;
  type: string;
  amount?: string;
  itemDescription?: string;
  status: string;
  donatedAt: string;
  karmaAwarded: number;
}

interface CommunityStats {
  totalUsers: number;
  totalGoodDeeds: number;
  totalDonations: number;
  totalHelpRequests: number;
  recentActivity: Array<{
    type: string;
    user: string;
    action: string;
    timestamp: Date;
  }>;
}

function Home() {
  const [selectedCategory, setSelectedCategory] = useState("all");
  const [selectedHallCategory, setSelectedHallCategory] = useState("all");
  const [realtimeActivity, setRealtimeActivity] = useState<string[]>([]);
  const [offeringHelp, setOfferingHelp] = useState<string | null>(null);
  const { socket } = useSocket();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Fetch good deeds
  const { data: goodDeeds, isLoading: goodDeedsLoading, refetch: refetchGoodDeeds } = useQuery<GoodDeed[]>({
    queryKey: ['/api/good-deeds'],
  });

  // Fetch help requests
  const { data: helpRequests, isLoading: helpRequestsLoading, refetch: refetchHelpRequests } = useQuery<HelpRequest[]>({
    queryKey: ['/api/help-requests'],
  });

  // Fetch hall of fame
  const { data: hallOfFame, isLoading: hallOfFameLoading, refetch: refetchHallOfFame } = useQuery<HallOfFameEntry[]>({
    queryKey: ['/api/hall-of-fame'],
  });

  // Fetch donations
  const { data: donations, isLoading: donationsLoading, refetch: refetchDonations } = useQuery<Donation[]>({
    queryKey: ['/api/donations'],
  });

  // Fetch community stats
  const { data: stats, isLoading: statsLoading, refetch: refetchStats } = useQuery<CommunityStats>({
    queryKey: ['/api/community/stats'],
  });

  // Socket event handlers
  useSocketEvent('good_deed_completed', useCallback((data: any) => {
    setRealtimeActivity(prev => [`${data.userId} completed a good deed (+${data.karmaAwarded} karma)`, ...prev.slice(0, 4)]);
    refetchStats();
    toast({
      title: "Good Deed Completed! 🎉",
      description: `Someone just earned ${data.karmaAwarded} karma points!`,
    });
  }, [refetchStats, toast]));

  useSocketEvent('donation_created', useCallback((data: any) => {
    setRealtimeActivity(prev => [`New ${data.type} donation made`, ...prev.slice(0, 4)]);
    refetchDonations();
    refetchStats();
    toast({
      title: "New Donation! ❤️",
      description: `A ${data.type} donation has been made to the community.`,
    });
  }, [refetchDonations, refetchStats, toast]));

  useSocketEvent('help_request_created', useCallback((data: any) => {
    setRealtimeActivity(prev => [`New help request: ${data.title}`, ...prev.slice(0, 4)]);
    refetchHelpRequests();
    refetchStats();
    toast({
      title: "Help Needed! 🙋‍♂️",
      description: data.title,
    });
  }, [refetchHelpRequests, refetchStats, toast]));

  const categories = [
    { id: "all", name: "All", icon: Sparkles, color: "bg-purple-500" },
    { id: "environmental", name: "Environmental", icon: Heart, color: "bg-green-500" },
    { id: "community", name: "Community", icon: Users, color: "bg-blue-500" },
    { id: "helping", name: "Helping", icon: Gift, color: "bg-red-500" },
    { id: "education", name: "Education", icon: Star, color: "bg-yellow-500" },
  ];

  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty) {
      case 'easy': return 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-300';
      case 'medium': return 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-300';
      case 'hard': return 'bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-300';
      default: return 'bg-gray-100 text-gray-800 dark:bg-gray-800 dark:text-gray-300';
    }
  };

  const getUrgencyColor = (urgency: string) => {
    switch (urgency) {
      case 'low': return 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-300';
      case 'medium': return 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-300';
      case 'high': return 'bg-orange-100 text-orange-800 dark:bg-orange-900 dark:text-orange-300';
      case 'critical': return 'bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-300';
      default: return 'bg-gray-100 text-gray-800 dark:bg-gray-800 dark:text-gray-300';
    }
  };

  const handleCompleteGoodDeed = async (goodDeedId: string) => {
    try {
      const response = await fetch('/api/good-deeds/complete', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'user-id': DEMO_USER_ID,
        },
        body: JSON.stringify({
          goodDeedId,
          proof: "Demo completion - user confirmed they completed this good deed",
        }),
      });

      if (response.ok) {
        // In a real app, this would trigger a toast notification and refetch data
        window.location.reload();
      }
    } catch (error) {
      console.error('Failed to complete good deed:', error);
    }
  };

  const handleOfferHelp = async (requestId: string) => {
    setOfferingHelp(requestId);
    try {
      const response = await fetch(`/api/help-requests/${requestId}`, {
        method: 'PATCH',
        headers: {
          'Content-Type': 'application/json',
          'user-id': DEMO_USER_ID,
        },
        body: JSON.stringify({
          helperId: DEMO_USER_ID,
          status: "in_progress",
        }),
      });

      if (response.ok) {
        // Show immediate visual feedback
        toast({
          title: "Help Offered!",
          description: "You've successfully offered to help with this request.",
        });
        
        // Refetch help requests to show updated status
        refetchHelpRequests();
        refetchStats();
      }
    } catch (error) {
      console.error('Failed to offer help:', error);
      toast({
        title: "Error",
        description: "Failed to offer help. Please try again.",
        variant: "destructive",
      });
    } finally {
      setOfferingHelp(null);
    }
  };

  return (
    <div className="min-h-screen">
      {/* Header */}
      <header className="bg-white/80 dark:bg-gray-900/80 backdrop-blur-md border-b border-gray-200 dark:border-gray-700 sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-gradient-to-r from-emerald-500 to-blue-500 rounded-lg flex items-center justify-center">
                <Heart className="w-6 h-6 text-white" />
              </div>
              <div>
                <h1 className="text-2xl font-bold bg-gradient-to-r from-emerald-600 to-blue-600 bg-clip-text text-transparent">
                  Goodness Hub
                </h1>
                <p className="text-sm text-gray-600 dark:text-gray-400">
                  Empowering Kindness in Communities
                </p>
              </div>
            </div>
            <div className="flex items-center space-x-4">
              <Badge variant="secondary" className="bg-emerald-100 text-emerald-800 dark:bg-emerald-900 dark:text-emerald-300">
                <Sparkles className="w-4 h-4 mr-1" />
                250 Karma
              </Badge>
              <Button variant="outline" size="sm">
                Sign In
              </Button>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Hero Section */}
        <div className="text-center mb-12">
          <h2 className="text-4xl font-bold text-gray-900 dark:text-white mb-4">
            Make a Difference Today
          </h2>
          <p className="text-xl text-gray-600 dark:text-gray-400 max-w-3xl mx-auto mb-8">
            Join our community of changemakers. Complete good deeds, help others, donate resources, 
            and earn karma points while making the world a better place.
          </p>
          
          {/* Real-time Activity Feed */}
          <AnimatePresence>
            {realtimeActivity.length > 0 && (
              <motion.div
                initial={{ opacity: 0, height: 0 }}
                animate={{ opacity: 1, height: "auto" }}
                exit={{ opacity: 0, height: 0 }}
                className="bg-gradient-to-r from-emerald-100/80 to-blue-100/80 dark:from-emerald-900/30 dark:to-blue-900/30 backdrop-blur-sm rounded-xl p-4 mb-8 border border-emerald-200 dark:border-emerald-700 max-w-2xl mx-auto"
              >
                <div className="flex items-center gap-2 mb-3">
                  <Zap className="text-yellow-500 animate-pulse" size={20} />
                  <h3 className="text-sm font-semibold text-gray-700 dark:text-gray-300">Live Community Activity</h3>
                </div>
                <ScrollArea className="h-20">
                  {realtimeActivity.map((activity, index) => (
                    <motion.div
                      key={index}
                      initial={{ opacity: 0, x: -20 }}
                      animate={{ opacity: 1, x: 0 }}
                      className="text-sm text-gray-600 dark:text-gray-400 mb-1 flex items-center gap-2"
                    >
                      <TrendingUp size={14} className="text-emerald-500" />
                      {activity}
                    </motion.div>
                  ))}
                </ScrollArea>
              </motion.div>
            )}
          </AnimatePresence>

          {/* Enhanced Community Stats */}
          {stats && (
            <div className="grid grid-cols-2 md:grid-cols-4 gap-6 max-w-4xl mx-auto mb-8">
              <motion.div
                whileHover={{ scale: 1.05 }}
                className="bg-gradient-to-br from-emerald-500/10 to-emerald-600/20 dark:from-emerald-400/20 dark:to-emerald-600/30 backdrop-blur-sm border border-emerald-200 dark:border-emerald-700 rounded-xl p-6 text-center"
              >
                <Users className="mx-auto mb-3 text-emerald-500" size={32} />
                <div className="text-3xl font-bold text-emerald-600 dark:text-emerald-400 mb-1">
                  {stats.totalUsers}
                </div>
                <div className="text-sm text-gray-600 dark:text-gray-400">Community Members</div>
              </motion.div>
              
              <motion.div
                whileHover={{ scale: 1.05 }}
                className="bg-gradient-to-br from-blue-500/10 to-blue-600/20 dark:from-blue-400/20 dark:to-blue-600/30 backdrop-blur-sm border border-blue-200 dark:border-blue-700 rounded-xl p-6 text-center"
              >
                <Heart className="mx-auto mb-3 text-blue-500" size={32} />
                <div className="text-3xl font-bold text-blue-600 dark:text-blue-400 mb-1">
                  {stats.totalGoodDeeds}
                </div>
                <div className="text-sm text-gray-600 dark:text-gray-400">Good Deeds Done</div>
              </motion.div>
              
              <motion.div
                whileHover={{ scale: 1.05 }}
                className="bg-gradient-to-br from-purple-500/10 to-purple-600/20 dark:from-purple-400/20 dark:to-purple-600/30 backdrop-blur-sm border border-purple-200 dark:border-purple-700 rounded-xl p-6 text-center"
              >
                <Gift className="mx-auto mb-3 text-purple-500" size={32} />
                <div className="text-3xl font-bold text-purple-600 dark:text-purple-400 mb-1">
                  {stats.totalDonations}
                </div>
                <div className="text-sm text-gray-600 dark:text-gray-400">Donations Made</div>
              </motion.div>
              
              <motion.div
                whileHover={{ scale: 1.05 }}
                className="bg-gradient-to-br from-orange-500/10 to-red-600/20 dark:from-orange-400/20 dark:to-red-600/30 backdrop-blur-sm border border-orange-200 dark:border-red-700 rounded-xl p-6 text-center"
              >
                <HelpCircle className="mx-auto mb-3 text-orange-500" size={32} />
                <div className="text-3xl font-bold text-red-600 dark:text-red-400 mb-1">
                  {stats.totalHelpRequests}
                </div>
                <div className="text-sm text-gray-600 dark:text-gray-400">Help Requests</div>
              </motion.div>
            </div>
          )}
        </div>

        {/* Main Tabs */}
        <Tabs defaultValue="good-deeds" className="w-full">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="good-deeds" className="flex items-center space-x-2">
              <Sparkles className="w-4 h-4" />
              <span>Good Deeds</span>
            </TabsTrigger>
            <TabsTrigger value="help-requests" className="flex items-center space-x-2">
              <HelpCircle className="w-4 h-4" />
              <span>Help Requests</span>
            </TabsTrigger>
            <TabsTrigger value="donations" className="flex items-center space-x-2">
              <Gift className="w-4 h-4" />
              <span>Donations</span>
            </TabsTrigger>
            <TabsTrigger value="hall-of-fame" className="flex items-center space-x-2">
              <Trophy className="w-4 h-4" />
              <span>Hall of Fame</span>
            </TabsTrigger>
          </TabsList>

          {/* Good Deeds Tab */}
          <TabsContent value="good-deeds" className="mt-6">
            <div className="mb-6">
              <h3 className="text-2xl font-bold text-gray-900 dark:text-white mb-4">
                Suggested Good Deeds
              </h3>
              <div className="flex flex-wrap gap-2 mb-4">
                {categories.map((category) => (
                  <Button
                    key={category.id}
                    variant={selectedCategory === category.id ? "default" : "outline"}
                    size="sm"
                    onClick={() => setSelectedCategory(category.id)}
                    className="flex items-center space-x-1"
                  >
                    <category.icon className="w-4 h-4" />
                    <span>{category.name}</span>
                  </Button>
                ))}
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {goodDeedsLoading ? (
                Array.from({ length: 6 }).map((_, i) => (
                  <Card key={i} className="animate-pulse">
                    <CardHeader>
                      <div className="h-4 bg-gray-200 rounded w-3/4"></div>
                      <div className="h-3 bg-gray-200 rounded w-full"></div>
                    </CardHeader>
                    <CardContent>
                      <div className="h-20 bg-gray-200 rounded mb-4"></div>
                      <div className="h-8 bg-gray-200 rounded"></div>
                    </CardContent>
                  </Card>
                ))
              ) : (
                goodDeeds?.map((deed) => (
                  <Card key={deed.id} className="hover:shadow-lg transition-shadow">
                    <CardHeader>
                      <div className="flex items-start justify-between">
                        <CardTitle className="text-lg">{deed.title}</CardTitle>
                        <Badge className={getDifficultyColor(deed.difficulty)}>
                          {deed.difficulty}
                        </Badge>
                      </div>
                      <CardDescription className="text-sm">
                        {deed.description}
                      </CardDescription>
                    </CardHeader>
                    <CardContent>
                      <div className="flex items-center justify-between mb-4">
                        <div className="flex items-center space-x-2">
                          <Badge variant="outline">{deed.category}</Badge>
                          <span className="text-sm text-gray-600 dark:text-gray-400">
                            {deed.timeRequired}
                          </span>
                        </div>
                        <div className="flex items-center space-x-1">
                          <Sparkles className="w-4 h-4 text-emerald-500" />
                          <span className="font-semibold text-emerald-600 dark:text-emerald-400">
                            +{deed.karmaReward}
                          </span>
                        </div>
                      </div>
                      <Button 
                        className="w-full"
                        onClick={() => handleCompleteGoodDeed(deed.id)}
                      >
                        Complete This Good Deed
                      </Button>
                    </CardContent>
                  </Card>
                ))
              )}
            </div>
          </TabsContent>

          {/* Enhanced Help Requests Tab */}
          <TabsContent value="help-requests" className="mt-6">
            <div className="mb-6">
              <div className="flex items-center justify-between mb-4">
                <div>
                  <h3 className="text-2xl font-bold text-gray-900 dark:text-white mb-2">
                    Community Help Requests
                  </h3>
                  <p className="text-gray-600 dark:text-gray-400">
                    Help your neighbors and community members with their requests.
                  </p>
                </div>
                <Button className="bg-emerald-600 hover:bg-emerald-700">
                  <HelpCircle className="w-4 h-4 mr-2" />
                  Submit Request
                </Button>
              </div>

              {/* Filter tabs for urgency */}
              <div className="flex flex-wrap gap-2 mb-6">
                {["all", "critical", "high", "medium", "low"].map((urgencyFilter) => (
                  <Badge
                    key={urgencyFilter}
                    variant={selectedCategory === urgencyFilter ? "default" : "outline"}
                    className={`cursor-pointer capitalize ${
                      urgencyFilter === "critical" ? "hover:bg-red-100" :
                      urgencyFilter === "high" ? "hover:bg-orange-100" :
                      urgencyFilter === "medium" ? "hover:bg-yellow-100" :
                      urgencyFilter === "low" ? "hover:bg-green-100" :
                      "hover:bg-gray-100"
                    }`}
                    onClick={() => setSelectedCategory(urgencyFilter)}
                  >
                    {urgencyFilter === "all" ? "All Requests" : `${urgencyFilter} urgency`}
                  </Badge>
                ))}
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {helpRequestsLoading ? (
                Array.from({ length: 6 }).map((_, i) => (
                  <Card key={i} className="animate-pulse">
                    <CardHeader>
                      <div className="h-4 bg-gray-200 rounded w-3/4"></div>
                      <div className="h-3 bg-gray-200 rounded w-full"></div>
                    </CardHeader>
                    <CardContent>
                      <div className="h-16 bg-gray-200 rounded"></div>
                    </CardContent>
                  </Card>
                ))
              ) : helpRequests?.length ? (
                helpRequests?.map((request) => (
                  <motion.div key={request.id} whileHover={{ y: -2 }} transition={{ duration: 0.2 }}>
                    <Card className="hover:shadow-xl transition-all duration-300 border-l-4 border-l-transparent hover:border-l-emerald-500">
                      <CardHeader>
                        <div className="flex items-start justify-between mb-2">
                          <CardTitle className="text-lg flex items-center gap-2">
                            {request.urgency === "critical" && <AlertCircle className="w-5 h-5 text-red-500" />}
                            {request.urgency === "high" && <AlertCircle className="w-5 h-5 text-orange-500" />}
                            {request.title}
                          </CardTitle>
                          <Badge className={`${getUrgencyColor(request.urgency)} animate-pulse`}>
                            {request.urgency}
                          </Badge>
                        </div>
                        <CardDescription className="line-clamp-2">{request.description}</CardDescription>
                      </CardHeader>
                      <CardContent>
                        <div className="flex items-center justify-between mb-4">
                          <div className="flex items-center gap-2">
                            <Badge variant="outline" className="text-xs">{request.category}</Badge>
                            <Badge variant="outline" className="text-xs bg-blue-50 text-blue-700 dark:bg-blue-900 dark:text-blue-300">
                              {request.status}
                            </Badge>
                          </div>
                        </div>
                        
                        {request.location && (
                          <div className="flex items-center gap-1 mb-3">
                            <MapPin className="w-4 h-4 text-gray-400" />
                            <span className="text-sm text-gray-600 dark:text-gray-400">
                              {request.location}
                            </span>
                          </div>
                        )}

                        {request.isFinancial && request.targetAmount && (
                          <div className="mb-4 bg-gradient-to-r from-green-50 to-blue-50 dark:from-green-900/20 dark:to-blue-900/20 rounded-lg p-3">
                            <div className="flex justify-between text-sm mb-2">
                              <span className="font-medium">Funding Progress</span>
                              <span className="font-bold">${request.currentAmount || "0"} / ${request.targetAmount}</span>
                            </div>
                            <Progress 
                              value={((parseInt(request.currentAmount || "0")) / parseInt(request.targetAmount)) * 100} 
                              className="h-3"
                            />
                            <div className="text-xs text-gray-600 dark:text-gray-400 mt-1">
                              {Math.round(((parseInt(request.currentAmount || "0")) / parseInt(request.targetAmount)) * 100)}% funded
                            </div>
                          </div>
                        )}

                        <div className="flex gap-2">
                          <Button 
                            className="flex-1 bg-emerald-600 hover:bg-emerald-700 transition-all duration-200" 
                            size="sm"
                            onClick={() => handleOfferHelp(request.id)}
                            disabled={offeringHelp === request.id}
                          >
                            {offeringHelp === request.id ? (
                              <>
                                <div className="w-4 h-4 mr-1 animate-spin rounded-full border-2 border-white border-t-transparent" />
                                Offering...
                              </>
                            ) : (
                              <>
                                <Heart className="w-4 h-4 mr-1" />
                                Offer Help
                              </>
                            )}
                          </Button>
                          {request.isFinancial && (
                            <Button variant="outline" size="sm">
                              <Gift className="w-4 h-4" />
                            </Button>
                          )}
                        </div>
                      </CardContent>
                    </Card>
                  </motion.div>
                ))
              ) : (
                <div className="col-span-full text-center py-12">
                  <HelpCircle className="w-16 h-16 text-gray-400 mx-auto mb-4" />
                  <h4 className="text-lg font-semibold text-gray-700 dark:text-gray-300 mb-2">
                    No Help Requests Found
                  </h4>
                  <p className="text-gray-600 dark:text-gray-400 mb-4">
                    Be the first to submit a help request or check back later.
                  </p>
                  <Button className="bg-emerald-600 hover:bg-emerald-700">
                    Submit First Request
                  </Button>
                </div>
              )}
            </div>
          </TabsContent>

          {/* Enhanced Donations Tab */}
          <TabsContent value="donations" className="mt-6">
            <div className="mb-8">
              <div className="flex items-center justify-between mb-4">
                <div>
                  <h3 className="text-3xl font-bold text-gray-900 dark:text-white mb-2 flex items-center gap-3">
                    <Gift className="w-8 h-8 text-purple-500" />
                    Donation Impact
                  </h3>
                  <p className="text-gray-600 dark:text-gray-400">
                    Track your donations and see their real-time community impact.
                  </p>
                </div>
                <Button className="bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700">
                  <Heart className="w-4 h-4 mr-2" />
                  Make Donation
                </Button>
              </div>
            </div>

            {donationsLoading ? (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {Array.from({ length: 6 }).map((_, i) => (
                  <Card key={i} className="animate-pulse">
                    <CardHeader>
                      <div className="h-4 bg-gray-200 rounded w-3/4"></div>
                      <div className="h-3 bg-gray-200 rounded w-full"></div>
                    </CardHeader>
                    <CardContent>
                      <div className="h-16 bg-gray-200 rounded"></div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            ) : donations?.length ? (
              <div className="space-y-6">
                {/* Summary Cards */}
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
                  <motion.div whileHover={{ scale: 1.02 }}>
                    <Card className="bg-gradient-to-br from-green-500/10 to-emerald-600/20 border-green-200 dark:border-green-700">
                      <CardContent className="p-6 text-center">
                        <Gift className="w-10 h-10 text-green-500 mx-auto mb-3" />
                        <div className="text-2xl font-bold text-green-600 dark:text-green-400">
                          {donations.filter(d => d.status === "completed").length}
                        </div>
                        <div className="text-sm text-gray-600 dark:text-gray-400">Completed Donations</div>
                      </CardContent>
                    </Card>
                  </motion.div>

                  <motion.div whileHover={{ scale: 1.02 }}>
                    <Card className="bg-gradient-to-br from-blue-500/10 to-indigo-600/20 border-blue-200 dark:border-blue-700">
                      <CardContent className="p-6 text-center">
                        <Sparkles className="w-10 h-10 text-blue-500 mx-auto mb-3" />
                        <div className="text-2xl font-bold text-blue-600 dark:text-blue-400">
                          {donations.reduce((sum, d) => sum + (d.karmaAwarded || 0), 0)}
                        </div>
                        <div className="text-sm text-gray-600 dark:text-gray-400">Karma Earned</div>
                      </CardContent>
                    </Card>
                  </motion.div>

                  <motion.div whileHover={{ scale: 1.02 }}>
                    <Card className="bg-gradient-to-br from-purple-500/10 to-pink-600/20 border-purple-200 dark:border-purple-700">
                      <CardContent className="p-6 text-center">
                        <Heart className="w-10 h-10 text-purple-500 mx-auto mb-3" />
                        <div className="text-2xl font-bold text-purple-600 dark:text-purple-400">
                          ${donations.filter(d => d.amount).reduce((sum, d) => sum + parseFloat(d.amount || "0"), 0).toFixed(0)}
                        </div>
                        <div className="text-sm text-gray-600 dark:text-gray-400">Total Financial</div>
                      </CardContent>
                    </Card>
                  </motion.div>
                </div>

                {/* Recent Donations List */}
                <div>
                  <h4 className="text-xl font-bold text-gray-900 dark:text-white mb-4">Recent Community Donations</h4>
                  <div className="space-y-4">
                    {donations.map((donation, index) => (
                      <motion.div
                        key={donation.id}
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ duration: 0.3, delay: index * 0.1 }}
                      >
                        <Card className="hover:shadow-md transition-all duration-300">
                          <CardContent className="p-6">
                            <div className="flex items-start justify-between">
                              <div className="flex items-center gap-4">
                                <div className={`p-3 rounded-full ${
                                  donation.type === "financial" ? "bg-green-100 text-green-600" : "bg-blue-100 text-blue-600"
                                }`}>
                                  {donation.type === "financial" ? 
                                    <Gift className="w-6 h-6" /> : 
                                    <Heart className="w-6 h-6" />
                                  }
                                </div>
                                <div>
                                  <h5 className="font-semibold text-gray-900 dark:text-white">
                                    {donation.type === "financial" ? 
                                      `Financial Donation - $${donation.amount}` : 
                                      donation.itemDescription || "Item Donation"
                                    }
                                  </h5>
                                  <div className="flex items-center gap-4 mt-1">
                                    <Badge className={`${
                                      donation.status === "completed" ? "bg-green-100 text-green-800" :
                                      donation.status === "pending" ? "bg-yellow-100 text-yellow-800" :
                                      "bg-gray-100 text-gray-800"
                                    }`}>
                                      {donation.status === "completed" && <CheckCircle className="w-3 h-3 mr-1" />}
                                      {donation.status}
                                    </Badge>
                                    <span className="text-sm text-gray-600 dark:text-gray-400 flex items-center gap-1">
                                      <Clock className="w-4 h-4" />
                                      {new Date(donation.donatedAt).toLocaleDateString()}
                                    </span>
                                  </div>
                                </div>
                              </div>
                              <div className="text-right">
                                <div className="flex items-center gap-1 text-emerald-600 dark:text-emerald-400">
                                  <Sparkles className="w-4 h-4" />
                                  <span className="font-bold">+{donation.karmaAwarded}</span>
                                </div>
                                <span className="text-xs text-gray-500">karma earned</span>
                              </div>
                            </div>
                          </CardContent>
                        </Card>
                      </motion.div>
                    ))}
                  </div>
                </div>
              </div>
            ) : (
              <div className="text-center py-12">
                <motion.div
                  initial={{ opacity: 0, scale: 0.8 }}
                  animate={{ opacity: 1, scale: 1 }}
                  transition={{ duration: 0.5 }}
                >
                  <Gift className="w-20 h-20 text-gray-400 mx-auto mb-6" />
                  <h4 className="text-xl font-bold text-gray-700 dark:text-gray-300 mb-3">
                    Start Making Impact Through Donations
                  </h4>
                  <p className="text-gray-600 dark:text-gray-400 mb-6 max-w-md mx-auto">
                    Your donations help community members in need and earn you karma points for your generosity.
                  </p>
                  <Button className="bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700">
                    <Heart className="w-4 h-4 mr-2" />
                    Make Your First Donation
                  </Button>
                </motion.div>
              </div>
            )}
          </TabsContent>

          {/* Enhanced Hall of Fame Tab */}
          <TabsContent value="hall-of-fame" className="mt-6">
            <div className="mb-8">
              <div className="flex items-center justify-between mb-4">
                <div>
                  <h3 className="text-3xl font-bold text-gray-900 dark:text-white mb-2 flex items-center gap-3">
                    <Trophy className="w-8 h-8 text-yellow-500" />
                    Hall of Fame
                  </h3>
                  <p className="text-gray-600 dark:text-gray-400">
                    Celebrating our top contributors and community champions who make a difference.
                  </p>
                </div>
                <div className="flex items-center gap-2">
                  <Star className="w-5 h-5 text-yellow-500" />
                  <span className="text-sm text-gray-600 dark:text-gray-400">Monthly Rankings</span>
                </div>
              </div>

              {/* Filter tabs for categories */}
              <div className="flex flex-wrap gap-2 mb-6">
                {["all", "karma_champion", "environmental_hero", "community_leader", "education_mentor", "newcomer_champion"].map((categoryFilter) => (
                  <Badge
                    key={categoryFilter}
                    variant={selectedHallCategory === categoryFilter ? "default" : "outline"}
                    className={`cursor-pointer capitalize ${
                      categoryFilter === "karma_champion" ? "hover:bg-yellow-100" :
                      categoryFilter === "environmental_hero" ? "hover:bg-green-100" :
                      categoryFilter === "community_leader" ? "hover:bg-blue-100" :
                      categoryFilter === "education_mentor" ? "hover:bg-purple-100" :
                      categoryFilter === "newcomer_champion" ? "hover:bg-pink-100" :
                      "hover:bg-gray-100"
                    }`}
                    onClick={() => setSelectedHallCategory(categoryFilter)}
                  >
                    {categoryFilter === "all" ? "All Categories" : categoryFilter.replace("_", " ")}
                  </Badge>
                ))}
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {hallOfFameLoading ? (
                Array.from({ length: 6 }).map((_, i) => (
                  <Card key={i} className="animate-pulse">
                    <CardHeader>
                      <div className="h-4 bg-gray-200 rounded w-3/4"></div>
                      <div className="h-3 bg-gray-200 rounded w-full"></div>
                    </CardHeader>
                    <CardContent>
                      <div className="h-16 bg-gray-200 rounded"></div>
                    </CardContent>
                  </Card>
                ))
              ) : hallOfFame?.length ? (
                hallOfFame.map((entry, index) => (
                  <motion.div
                    key={entry.id}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.4, delay: index * 0.1 }}
                    whileHover={{ y: -5, scale: 1.02 }}
                  >
                    <Card className={`hover:shadow-2xl transition-all duration-300 relative overflow-hidden ${
                      index === 0 ? "ring-2 ring-yellow-400 bg-gradient-to-br from-yellow-50/50 to-orange-50/50 dark:from-yellow-900/20 dark:to-orange-900/20" :
                      index === 1 ? "ring-2 ring-gray-400 bg-gradient-to-br from-gray-50/50 to-slate-50/50 dark:from-gray-900/20 dark:to-slate-900/20" :
                      index === 2 ? "ring-2 ring-amber-600 bg-gradient-to-br from-amber-50/50 to-yellow-50/50 dark:from-amber-900/20 dark:to-yellow-900/20" :
                      "hover:ring-2 hover:ring-emerald-200 dark:hover:ring-emerald-800"
                    }`}>
                      {/* Ranking Badge */}
                      {index < 3 && (
                        <div className={`absolute top-2 right-2 w-8 h-8 rounded-full flex items-center justify-center text-white font-bold text-sm ${
                          index === 0 ? "bg-yellow-500" :
                          index === 1 ? "bg-gray-500" :
                          "bg-amber-600"
                        }`}>
                          {index + 1}
                        </div>
                      )}

                      <CardHeader>
                        <div className="flex items-center space-x-3">
                          <div className={`p-2 rounded-full ${
                            entry.category === "karma_champion" ? "bg-yellow-100 text-yellow-600" :
                            entry.category === "environmental_hero" ? "bg-green-100 text-green-600" :
                            entry.category === "community_leader" ? "bg-blue-100 text-blue-600" :
                            entry.category === "education_mentor" ? "bg-purple-100 text-purple-600" :
                            entry.category === "newcomer_champion" ? "bg-pink-100 text-pink-600" :
                            "bg-gray-100 text-gray-600"
                          }`}>
                            {entry.category === "karma_champion" && <Sparkles className="w-6 h-6" />}
                            {entry.category === "environmental_hero" && <Heart className="w-6 h-6" />}
                            {entry.category === "community_leader" && <Users className="w-6 h-6" />}
                            {entry.category === "education_mentor" && <Star className="w-6 h-6" />}
                            {entry.category === "newcomer_champion" && <Trophy className="w-6 h-6" />}
                            {!["karma_champion", "environmental_hero", "community_leader", "education_mentor", "newcomer_champion"].includes(entry.category) && <Trophy className="w-6 h-6" />}
                          </div>
                          <div>
                            <CardTitle className="text-lg font-bold">{entry.achievement}</CardTitle>
                            <CardDescription className="capitalize flex items-center gap-1">
                              <Clock className="w-4 h-4" />
                              {entry.period} champion
                            </CardDescription>
                          </div>
                        </div>
                      </CardHeader>
                      <CardContent>
                        <p className="text-sm text-gray-600 dark:text-gray-400 mb-4 leading-relaxed">
                          {entry.description}
                        </p>
                        <div className="flex items-center justify-between">
                          <div className="text-right">
                            <div className="text-3xl font-bold bg-gradient-to-r from-emerald-600 to-blue-600 bg-clip-text text-transparent">
                              {entry.value.toLocaleString()}
                            </div>
                            <div className="text-xs text-gray-500 dark:text-gray-400">
                              {entry.category.includes("karma") ? "karma points" : "impact score"}
                            </div>
                          </div>
                          {index < 3 && (
                            <div className="flex items-center gap-1">
                              {index === 0 && <Trophy className="w-5 h-5 text-yellow-500" />}
                              {index === 1 && <Trophy className="w-5 h-5 text-gray-500" />}
                              {index === 2 && <Trophy className="w-5 h-5 text-amber-600" />}
                            </div>
                          )}
                        </div>
                      </CardContent>
                    </Card>
                  </motion.div>
                ))
              ) : (
                <div className="col-span-full text-center py-12">
                  <motion.div
                    initial={{ opacity: 0, scale: 0.8 }}
                    animate={{ opacity: 1, scale: 1 }}
                    transition={{ duration: 0.5 }}
                  >
                    <Trophy className="w-20 h-20 text-gray-400 mx-auto mb-6" />
                    <h4 className="text-xl font-bold text-gray-700 dark:text-gray-300 mb-3">
                      Hall of Fame Coming Soon!
                    </h4>
                    <p className="text-gray-600 dark:text-gray-400 mb-6 max-w-md mx-auto">
                      Complete good deeds, help others, and make donations to earn your place among our community champions.
                    </p>
                    <Button className="bg-gradient-to-r from-emerald-600 to-blue-600 hover:from-emerald-700 hover:to-blue-700">
                      <Sparkles className="w-4 h-4 mr-2" />
                      Start Making Impact
                    </Button>
                  </motion.div>
                </div>
              )}
            </div>
          </TabsContent>
        </Tabs>
      </main>
    </div>
  );
}

export default Home;