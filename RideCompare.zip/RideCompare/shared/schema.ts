import { sql } from "drizzle-orm";
import { pgTable, text, varchar, decimal, integer, timestamp, jsonb, boolean } from "drizzle-orm/pg-core";
import { relations } from "drizzle-orm";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Users table
export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  username: text("username").notNull().unique(),
  email: text("email").notNull().unique(),
  fullName: text("full_name").notNull(),
  bio: text("bio"),
  avatar: text("avatar"),
  karmaPoints: integer("karma_points").default(0),
  level: integer("level").default(1),
  location: text("location"),
  isVerified: boolean("is_verified").default(false),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Good deeds table
export const goodDeeds = pgTable("good_deeds", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  title: text("title").notNull(),
  description: text("description").notNull(),
  category: text("category").notNull(), // environmental, community, helping, education, etc.
  difficulty: text("difficulty").notNull(), // easy, medium, hard
  karmaReward: integer("karma_reward").notNull(),
  timeRequired: text("time_required"), // "5 minutes", "1 hour", etc.
  location: text("location"),
  isActive: boolean("is_active").default(true),
  createdAt: timestamp("created_at").defaultNow(),
});

// User completed good deeds
export const userGoodDeeds = pgTable("user_good_deeds", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull().references(() => users.id),
  goodDeedId: varchar("good_deed_id").notNull().references(() => goodDeeds.id),
  completedAt: timestamp("completed_at").defaultNow(),
  proof: text("proof"), // optional photo/description of completion
  karmaAwarded: integer("karma_awarded").notNull(),
  isVerified: boolean("is_verified").default(false),
});

// Donations table
export const donations = pgTable("donations", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  donorId: varchar("donor_id").notNull().references(() => users.id),
  recipientId: varchar("recipient_id").references(() => users.id), // optional if community donation
  type: text("type").notNull(), // financial, item
  amount: decimal("amount", { precision: 10, scale: 2 }), // for financial donations
  itemDescription: text("item_description"), // for item donations
  status: text("status").notNull().default("pending"), // pending, completed, delivered
  trackingInfo: jsonb("tracking_info"), // real-time tracking data
  donatedAt: timestamp("donated_at").defaultNow(),
  deliveredAt: timestamp("delivered_at"),
  karmaAwarded: integer("karma_awarded").notNull().default(0),
});

// Help requests table
export const helpRequests = pgTable("help_requests", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  requesterId: varchar("requester_id").notNull().references(() => users.id),
  title: text("title").notNull(),
  description: text("description").notNull(),
  category: text("category").notNull(),
  urgency: text("urgency").notNull(), // low, medium, high, critical
  location: text("location"),
  isFinancial: boolean("is_financial").default(false),
  targetAmount: decimal("target_amount", { precision: 10, scale: 2 }),
  currentAmount: decimal("current_amount", { precision: 10, scale: 2 }).default("0"),
  status: text("status").notNull().default("open"), // open, in_progress, completed, closed
  helperId: varchar("helper_id").references(() => users.id),
  createdAt: timestamp("created_at").defaultNow(),
  resolvedAt: timestamp("resolved_at"),
});

// Hall of Fame entries
export const hallOfFame = pgTable("hall_of_fame", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull().references(() => users.id),
  achievement: text("achievement").notNull(),
  description: text("description").notNull(),
  category: text("category").notNull(), // top_donor, most_helpful, community_champion, etc.
  period: text("period").notNull(), // weekly, monthly, yearly, all_time
  value: integer("value").notNull(), // karma points, donations, etc.
  achievedAt: timestamp("achieved_at").defaultNow(),
  isActive: boolean("is_active").default(true),
});

// Relations
export const usersRelations = relations(users, ({ many }) => ({
  goodDeeds: many(userGoodDeeds),
  donations: many(donations),
  helpRequests: many(helpRequests),
  hallOfFameEntries: many(hallOfFame),
}));

export const goodDeedsRelations = relations(goodDeeds, ({ many }) => ({
  userCompletions: many(userGoodDeeds),
}));

export const userGoodDeedsRelations = relations(userGoodDeeds, ({ one }) => ({
  user: one(users, {
    fields: [userGoodDeeds.userId],
    references: [users.id],
  }),
  goodDeed: one(goodDeeds, {
    fields: [userGoodDeeds.goodDeedId],
    references: [goodDeeds.id],
  }),
}));

export const donationsRelations = relations(donations, ({ one }) => ({
  donor: one(users, {
    fields: [donations.donorId],
    references: [users.id],
  }),
  recipient: one(users, {
    fields: [donations.recipientId],
    references: [users.id],
  }),
}));

export const helpRequestsRelations = relations(helpRequests, ({ one }) => ({
  requester: one(users, {
    fields: [helpRequests.requesterId],
    references: [users.id],
  }),
  helper: one(users, {
    fields: [helpRequests.helperId],
    references: [users.id],
  }),
}));

export const hallOfFameRelations = relations(hallOfFame, ({ one }) => ({
  user: one(users, {
    fields: [hallOfFame.userId],
    references: [users.id],
  }),
}));

// Insert schemas
export const insertUserSchema = createInsertSchema(users).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertGoodDeedSchema = createInsertSchema(goodDeeds).omit({
  id: true,
  createdAt: true,
});

export const insertUserGoodDeedSchema = createInsertSchema(userGoodDeeds).omit({
  id: true,
  completedAt: true,
});

export const insertDonationSchema = createInsertSchema(donations).omit({
  id: true,
  donatedAt: true,
});

export const insertHelpRequestSchema = createInsertSchema(helpRequests).omit({
  id: true,
  createdAt: true,
});

export const insertHallOfFameSchema = createInsertSchema(hallOfFame).omit({
  id: true,
  achievedAt: true,
});

// Types
export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;
export type GoodDeed = typeof goodDeeds.$inferSelect;
export type InsertGoodDeed = z.infer<typeof insertGoodDeedSchema>;
export type UserGoodDeed = typeof userGoodDeeds.$inferSelect;
export type InsertUserGoodDeed = z.infer<typeof insertUserGoodDeedSchema>;
export type Donation = typeof donations.$inferSelect;
export type InsertDonation = z.infer<typeof insertDonationSchema>;
export type HelpRequest = typeof helpRequests.$inferSelect;
export type InsertHelpRequest = z.infer<typeof insertHelpRequestSchema>;
export type HallOfFameEntry = typeof hallOfFame.$inferSelect;
export type InsertHallOfFameEntry = z.infer<typeof insertHallOfFameSchema>;

// API schemas
export const completeGoodDeedSchema = z.object({
  goodDeedId: z.string(),
  proof: z.string().optional(),
});

export const createDonationSchema = z.object({
  recipientId: z.string().optional(),
  type: z.enum(["financial", "item"]),
  amount: z.number().optional(),
  itemDescription: z.string().optional(),
});

export const createHelpRequestSchema = z.object({
  title: z.string().min(1, "Title is required"),
  description: z.string().min(10, "Description must be at least 10 characters"),
  category: z.string(),
  urgency: z.enum(["low", "medium", "high", "critical"]),
  location: z.string().optional(),
  isFinancial: z.boolean().default(false),
  targetAmount: z.number().optional(),
});

export type CompleteGoodDeedRequest = z.infer<typeof completeGoodDeedSchema>;
export type CreateDonationRequest = z.infer<typeof createDonationSchema>;
export type CreateHelpRequestRequest = z.infer<typeof createHelpRequestSchema>;

// Dashboard data types
export interface UserDashboard {
  user: User;
  recentGoodDeeds: UserGoodDeed[];
  donations: Donation[];
  helpRequests: HelpRequest[];
  hallOfFameEntries: HallOfFameEntry[];
  stats: {
    totalKarma: number;
    goodDeedsCompleted: number;
    donationsAmount: number;
    helpRequestsFulfilled: number;
  };
}

export interface CommunityStats {
  totalUsers: number;
  totalGoodDeeds: number;
  totalDonations: number;
  totalHelpRequests: number;
  recentActivity: Array<{
    type: string;
    user: string;
    action: string;
    timestamp: Date;
  }>;
}
